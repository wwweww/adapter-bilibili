#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project :BiliInteraction 
@File    :__init__.py.py
@Author  :Asadz
@Date    :2023/1/11 19:45 
"""
from .interaction import login


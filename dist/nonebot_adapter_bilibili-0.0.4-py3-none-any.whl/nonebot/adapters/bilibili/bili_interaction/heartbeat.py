#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
@Project :nonebotAdapterTest 
@File    :heartbeat.py
@Author  :Asadz
@Date    :2023/1/12 7:10 
"""
from asyncio import sleep



